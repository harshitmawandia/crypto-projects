import Includes.*;

public class Block{
	public MerkleTree mtree;
	public Block previous;
	public Block next;
	public String dgst;
	public int year;
	public String value;
}
